const countDown =  require('./countDown');

test('countDown 987654321', () => {
  expect(countDown(9)).toBe('987654321');
});