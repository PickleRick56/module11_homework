function countDown(num) {
    let subsequence='';
    for (let i = num; i > 0; i--) {
        subsequence += i;
    }
    return subsequence;
}

module.exports = countDown;