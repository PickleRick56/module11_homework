const countDown =  require('./countDown');

test('countDown 0', () => {
  expect(countDown(0)).toBe('0');
});