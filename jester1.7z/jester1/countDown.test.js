const countDown =  require('./countDown');

test('countDown 321', () => {
  expect(countDown(3)).toBe('321');
});